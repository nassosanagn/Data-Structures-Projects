#include "TSEvr.h"



int TSEvr_setValue (TStoixeiouEvr *target, TStoixeiouEvr source){}

int TSEvr_readValue (FILE *from,  TStoixeiouEvr *Elem){}

int TSEvr_writeValue(FILE *to, TStoixeiouEvr Elem){}

