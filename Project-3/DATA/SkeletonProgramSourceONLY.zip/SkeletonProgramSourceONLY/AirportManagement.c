/************************************************************************
Programma pelaths	: AirportManagement.c
Syggrafeas			: 
Skopos				: skeleton main for askhsh 3
*************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "TSEvr.h"
#include "TSDDA.h"
#include "Evretirio.h"

int main(int argc, char *argv[])
{ EvrPtr E;

  E=EvrConstruct(7200);
  
  getchar();	
  return 0;
}

